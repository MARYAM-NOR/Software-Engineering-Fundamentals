"""myproject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, re_path
from app import views, forms
import django.contrib.auth.views
from django.contrib.auth.views import LoginView, LogoutView
from datetime import datetime
admin.autodiscover()

urlpatterns = [
    path('admin/', admin.site.urls),
    re_path(r'^$', views.home, name='home'),
    re_path(r'^contact$', views.contact, name='contact'),
    re_path(r'^about$', views.about, name='about'),
    path("register/", views.register, name="register"),
    path("login/", views.user_login, name="login"),
    re_path(r'^logout$',
        LogoutView.as_view(template_name = 'app/index.html'),
        name='logout'),
    path("menu/", views.menu, name="menu"),
    path("customer/", views.customer_module, name="customer_module"),
    path("employee/", views.employee_module, name="employee_module"),
    path("driver/", views.driver_module, name="driver_module"),
    path("supplier/", views.supplier_module, name="supplier_module"),
    path("make_order/", views.make_order, name="make_order"),
    path("track_order/", views.track_order, name="track_order"),
    path("refund_order/", views.refund_order_page, name="refund_order_page"),
    path("customer/request_refund/<int:order_id>/", views.request_refund, name="request_refund"),
    path("cancel_order/<int:order_id>/", views.cancel_order, name="cancel_order"),
    path('checkout/', views.checkout, name='checkout'),
    path('profile_management/', views.profile_management, name='profile_management'),
    path("driver/profile/", views.driver_profile, name="driver_profile"),
    path("supplier/profile/", views.supplier_profile, name="supplier_profile"),
    path("supplier/update_inventory/", views.update_inventory, name="update_inventory"),
    path("supplier/prepare_order/", views.prepare_order, name="prepare_order"),
    path("manage_driver/", views.manage_driver, name="manage_driver"),
    path("approve_driver/<int:driver_id>/", views.approve_driver, name="approve_driver"),
    path('employee/profile/', views.user_profile, name='user_profile'),
    path('employee/employee_profile', views.profile_management, name='employee_profile'),

]
