"""
Definition of models.
"""

from django.db import models

from django.contrib.auth.models import User

from django.utils.timezone import now

class Order(models.Model):
    PETROL_CHOICES = [
        ("RON95", "RON95"),
        ("RON97", "RON97"),
        ("Diesel", "Diesel"),
    ]

    PAYMENT_METHODS = [
        ("E-Wallet", "E-Wallet"),
        ("FPX", "FPX"),
        ("Credit/Debit", "Credit/Debit"),
        ("Cash", "Cash"),
    ]

    customer = models.ForeignKey(User, on_delete=models.CASCADE)
    petrol_type = models.CharField(max_length=10, choices=PETROL_CHOICES)
    liters = models.PositiveIntegerField()
    total_price = models.DecimalField(max_digits=7, decimal_places=2, default=0.00)  # Store calculated price
    address = models.TextField(null=True, blank=True)  # Store customer's address at the time of order
    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHODS, default="Cash")  
    order_date = models.DateTimeField(default=now)

    is_ready = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.customer.username} - {self.petrol_type} ({self.liters}L) - RM{self.total_price}"
    
class Petrol(models.Model):
    PETROL_TYPES = [
        ('RON95', 'RON95'),
        ('RON97', 'RON97'),
        ('Diesel', 'Diesel'),
    ]

    petrol_type = models.CharField(max_length=10, choices=PETROL_TYPES, unique=True)
    price_per_liter = models.DecimalField(max_digits=5, decimal_places=2)  # e.g., 2.50
    available_amount = models.PositiveIntegerField()  # Liters available

    def __str__(self):
        return f"{self.petrol_type} - RM{self.price_per_liter}/L"
    
class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)  # Link to User
    phone_number = models.CharField(max_length=15, blank=True, null=True)  # Store phone numbers

    def __str__(self):
        return self.user.username
    
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    address = models.TextField()
    phone_number = models.CharField(max_length=15, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)  # Add this line
    is_driver = models.BooleanField(default=False)  # To identify if user is a driver

    def __str__(self):
        return self.name
    
class SupplierProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    company_name = models.CharField(max_length=255)
    phone_number = models.CharField(max_length=15, blank=True, null=True)
    address = models.TextField()

    def __str__(self):
        return self.company_name

class RefundRequest(models.Model):
    STATUS_CHOICES = [
        ("Pending", "Pending"),
        ("Approved", "Approved"),
        ("Denied", "Denied"),
    ]

    order = models.OneToOneField(Order, on_delete=models.CASCADE)
    customer = models.ForeignKey(User, on_delete=models.CASCADE)  # Ensure this exists
    reason = models.TextField()
    status = models.CharField(max_length=20, default="Pending")
    request_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Refund Request for {self.order} - {self.status}"
    
class RefundOrder(models.Model):
    customer_name = models.CharField(max_length=255)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=50, choices=[('Pending', 'Pending'), ('Approved', 'Approved'), ('Rejected', 'Rejected')])
    requested_date = models.DateTimeField(auto_now_add=True)

    def _str_(self):
        return f"{self.customer_name} - {self.status}"
    
class Driver(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=15)
    vehicle_info = models.CharField(max_length=255)
    is_approved = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def _str_(self):
        return self.name
