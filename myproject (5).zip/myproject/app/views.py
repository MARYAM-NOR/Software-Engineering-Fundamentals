from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.models import Group
from django.contrib import messages
from django.urls import reverse
from .forms import RegisterForm  # Import the registration form

# Create your views here.
from django.http import HttpRequest, HttpResponse
from django.template import RequestContext
from datetime import datetime
from django.utils.timezone import now

from django.contrib.auth.decorators import login_required
from .models import Order, Profile, Petrol, SupplierProfile, RefundOrder, RefundRequest, UserProfile, Driver
from .forms import ProfileForm, SupplierProfileForm, PetrolForm

def home(request):
    """Renders the home page."""
    assert isinstance(request, HttpRequest)
    if request.user.is_authenticated:
        return(redirect('/menu'))
    else:
        return render(
            request,
            'app/index.html',
            {
                'title':'Home Page',
                'year': datetime.now().year,
            }
        )

def contact(request):
    """Renders the contact page."""
    assert isinstance(request, HttpRequest)
    return render(
        request,
        'app/contact.html',
        {
            'title':'Contact',
            'message':'Dr. Yeoh.',
            'year':datetime.now().year,
        }
    )

def about(request):
    """Renders the about page."""
    assert isinstance(request, HttpRequest)
    return render(
        request,
        'app/about.html',
        {
            'title':'ABC System',
            'message':'This application processes ...',
            'year':datetime.now().year,
        }
    )

def register(request):
    """Handles user registration."""
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()  # Save new user
            
            # Get role from the form
            role = request.POST.get("role")

            # Assign user to the selected group
            if role == "customer":
                group = Group.objects.get(name="customer")
            elif role == "driver":
                group = Group.objects.get(name="driver")
            else:
                group = None  # Just in case

            if group:
                user.groups.add(group)  # Add user to the group

            login(request, user)  # Log in the user automatically
            return redirect("menu")  # Redirect after signup

    else:
        form = RegisterForm()

    return render(request, "app/register.html", {"form": form})

def user_login(request):
    """Handles user login."""
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data["username"]
            password = form.cleaned_data["password"]
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                
                # Redirect based on user role
                if user.groups.filter(name='customer').exists():
                    return redirect('customer_module')
                elif user.groups.filter(name='employee').exists():
                    return redirect('employee_module')
                elif user.groups.filter(name='driver').exists():
                    return redirect('driver_module')
                elif user.groups.filter(name='supplier').exists():
                    return redirect('supplier_module')
                
                # Default case if no group found
                return redirect("home")

    else:
        form = AuthenticationForm()

    return render(request, "app/login.html", {"form": form})

def user_logout(request):
    """Handles user logout."""
    logout(request)
    return redirect("home")

@login_required
def menu(request):
    if request.user.groups.filter(name='customer').exists():
        return redirect('customer_module')
    elif request.user.groups.filter(name='employee').exists():
        return redirect('employee_module')
    elif request.user.groups.filter(name='driver').exists():
        return redirect('driver_module')
    elif request.user.groups.filter(name='supplier').exists():
        return redirect('supplier_module')
    else:
        return render(request, "app/menu.html", {"title": "Undefined User"})
    
@login_required
def customer_module(request):
    return render(request, "app/customer_module.html", {"title": "Customer Module"})

@login_required
def employee_module(request):
    return render(request, "app/employee_module.html", {"title": "Employee Module"})

@login_required
def driver_module(request):
    return render(request, "app/driver_module.html", {"title": "Driver Module"})

@login_required
def supplier_module(request):
    return render(request, "app/supplier_module.html", {"title": "Supplier Module"})

@login_required
def make_order(request):
    if request.method == "POST":
        petrol_type = request.POST.get("petrol_type")
        liters = request.POST.get("liters")

        # Store order details in session
        request.session["petrol_type"] = petrol_type
        request.session["liters"] = liters
        request.session.modified = True  # Ensure session is saved

        return redirect("checkout")  # Redirect to checkout page

    return render(request, "app/make_order.html")

@login_required
def customer_module(request):
    orders = Order.objects.filter(customer=request.user).order_by("-order_date")  # Get latest orders
    return render(request, "app/customer_module.html", {"title": "Customer Module", "orders": orders})

@login_required
def track_order(request):
    customer_orders = Order.objects.filter(customer=request.user)  # Get all customer orders
    refunded_orders = RefundRequest.objects.values_list("order_id", flat=True)  # Get refunded order IDs

    # Exclude refunded orders from being displayed
    trackable_orders = customer_orders.exclude(id__in=refunded_orders)

    return render(request, "app/track_order.html", {
        "orders": trackable_orders,  # Only show orders that have no refund request
    })

@login_required
def refund_order_page(request):
    customer_orders = Order.objects.filter(customer=request.user)
    refunded_orders = RefundRequest.objects.values_list("order_id", flat=True)
    refundable_orders = customer_orders.exclude(id__in=refunded_orders)
    refund_status = RefundRequest.objects.filter(order__customer=request.user)

    if request.method == "POST":
        order_id = request.POST.get("order_id")
        try:
            order = Order.objects.get(id=order_id, customer=request.user)
            if RefundRequest.objects.filter(order=order).exists():
                messages.warning(request, "Refund request already submitted for this order.")
            else:
                RefundRequest.objects.create(order=order, customer=request.user, status="Pending")  # FIXED HERE
                messages.success(request, "Refund request submitted successfully.")
            return redirect("refund_order_page")
        except Order.DoesNotExist:
            messages.error(request, "Invalid order selected.")

    return render(request, "app/refund_order.html", {
        "orders": refundable_orders,
        "refund_status": refund_status,
    })

@login_required
def cancel_order(request, order_id):
    """Handles order cancellation (refund)."""
    order = get_object_or_404(Order, id=order_id, customer=request.user)
    order.delete()  # Remove the order from the database
    messages.success(request, "Your order has been successfully refunded.")
    return redirect("refund_order_page")  # Redirect back to refund page

@login_required
def profile_management(request):
    profile, created = Profile.objects.get_or_create(user=request.user)
    form = ProfileForm(instance=profile, user=request.user)

    if request.method == "POST":
        form = ProfileForm(request.POST, instance=profile, user=request.user)
        if form.is_valid():
            form.save()
            redirect_url = reverse("driver_module") if hasattr(profile, "is_driver") and profile.is_driver else reverse("customer_module")
            return redirect(redirect_url)

    redirect_url = reverse("driver_module") if hasattr(profile, "is_driver") and profile.is_driver else reverse("customer_module")

    return render(request, "app/profile_management.html", {"form": form, "is_driver": hasattr(profile, "is_driver") and profile.is_driver, "redirect_url": redirect_url})

@login_required
def checkout(request):
    profile = get_object_or_404(Profile, user=request.user)

    # Retrieve order details from session
    petrol_type = request.session.get('petrol_type')
    liters = request.session.get('liters')

    if not petrol_type or not liters:
        return HttpResponse("Error: Petrol type or liters missing in session.", status=400)

    petrol = get_object_or_404(Petrol, petrol_type=petrol_type)

    price_per_liter = petrol.price_per_liter
    total_price = price_per_liter * int(liters)

    if request.method == "POST":
        payment_method = request.POST.get('payment_method')

        # Save order to database
        Order.objects.create(
            customer=request.user,
            petrol_type=petrol_type,
            liters=liters,
            order_date=datetime.now(),
        )

        # Clear session data
        request.session.pop('petrol_type', None)
        request.session.pop('liters', None)

        return redirect('track_order')  # Redirect to track order page instead of confirmation

    return render(request, 'app/checkout.html', {
        'petrol_type': petrol_type,
        'liters': liters,
        'price_per_liter': price_per_liter,
        'total_price': total_price,
        'address': profile.address,
        'payment_methods': ["E-Wallet", "FPX", "Credit/Debit", "Cash"]
    })

@login_required
def driver_profile(request):
    # Ensure a profile exists for the user
    profile, created = Profile.objects.get_or_create(user=request.user)

    # Ensure `form` is always defined before it's used
    form = ProfileForm(instance=profile, user=request.user)

    if request.method == "POST":
        form = ProfileForm(request.POST, instance=profile, user=request.user)
        if form.is_valid():
            form.save()
            return redirect("driver_module")  # Redirect back to driver module

    return render(request, "app/driver_profile.html", {"form": form})

@login_required
def supplier_profile(request):
    profile, created = SupplierProfile.objects.get_or_create(user=request.user)
    
    if request.method == "POST":
        form = SupplierProfileForm(request.POST, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, "Profile updated successfully!")
            return redirect("supplier_module")
    else:
        form = SupplierProfileForm(instance=profile)

    return render(request, "app/supplier_profile.html", {"form": form})

def update_inventory(request):
    petrol_items = Petrol.objects.all()  # Fetch all petrol types

    if request.method == "POST":
        forms = []
        for petrol in petrol_items:
            form = PetrolForm(request.POST, instance=petrol, prefix=str(petrol.id))  # Prefix to differentiate each form
            forms.append(form)

        if all(form.is_valid() for form in forms):  # Validate each form separately
            for form in forms:
                print(f"Saving: {form.cleaned_data}")  # Debugging: Print correct values before saving
                form.save()  # Save the form linked to the correct petrol instance
            print("All forms saved successfully!")
            return redirect("supplier_module")  # Redirect after saving
        else:
            print("Form validation failed:", [form.errors for form in forms])  # Debug invalid forms

    else:
        forms = [PetrolForm(instance=petrol, prefix=str(petrol.id)) for petrol in petrol_items]  # Load existing data

    return render(request, "app/update_inventory.html", {"forms": forms})

def prepare_order(request):
    pending_orders = Order.objects.filter(is_ready=False)  # Only show orders not yet ready

    if request.method == "POST":
        order_id = request.POST.get("order_id")
        order = get_object_or_404(Order, id=order_id)
        order.is_ready = True  # Mark as ready
        order.save()
        return redirect("prepare_order")  # Refresh page after update

    return render(request, "app/prepare_order.html", {"orders": pending_orders})

@login_required
def request_refund(request, order_id):
    order = get_object_or_404(Order, id=order_id, customer=request.user)

    # Check if a refund request already exists for this order
    refund, created = RefundRequest.objects.get_or_create(
        order=order,
        customer=request.user,
        defaults={"reason": "Customer requested a refund", "request_date": now()}
    )

    if not created:
        print("Refund request already exists!")

    return redirect("customer_module")  # Redirect to customer dashboard

@login_required
def refund_details(request):
    refund_orders = RefundRequest.objects.select_related("order__customer").all()
    return render(request, "app/refund_details.html", {"refund_orders": refund_orders})

@login_required
def process_refund(request, refund_id):
    refund = get_object_or_404(RefundRequest, id=refund_id)

    if request.method == "POST":
        action = request.POST.get("action")
        if action == "approve":
            refund.status = "Approved"
        elif action == "deny":
            refund.status = "Denied"
        refund.save()

    return redirect("request_refund")

@login_required
def manage_driver(request):
    drivers = Driver.objects.all()
    return render(request, "app/manage_driver.html", {"drivers": drivers})

@login_required
def approve_driver(request, driver_id):
    driver = get_object_or_404(Driver, id=driver_id)
    driver.is_approved = True
    driver.save()
    return redirect("manage_driver")  # Redirect back to the manage driver page

@login_required
def user_profile(request):
    userprofile = UserProfile.objects.get(user=request.user)
    profile = Profile.objects.get(user=request.user)
    supplierprofile = SupplierProfile.objects.get(user=request.user)
    
    context = {
        'userprofile': userprofile,
        'profile': profile,
        'supplierprofile': supplierprofile,
    }
    return render(request, 'profile.html', context)

@login_required
def employee_profile(request):
        # Ensure a profile exists for the user
    profile, created = Profile.objects.get_or_create(user=request.user)

    # Ensure form is always defined before it's used
    form = ProfileForm(instance=profile, user=request.user)

    if request.method == "POST":
        form = ProfileForm(request.POST, instance=profile, user=request.user)
        if form.is_valid():
            form.save()
            return redirect("employee_module")  # Redirect back to employee module

    return render(request, "app/employee_profile.html",{"form":form})