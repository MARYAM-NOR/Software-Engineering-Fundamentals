from django.contrib import admin
from .models import Order, Petrol

@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ("customer", "petrol_type", "liters", "order_date")  # Columns in admin
    search_fields = ("customer__username", "petrol_type")  # Searchable fields
    list_filter = ("petrol_type", "order_date")  # Filters in sidebar

admin.site.register(Petrol)