"""
Definition of forms.
"""

from django import forms
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.utils.translation import gettext_lazy as _
from .models import Profile, SupplierProfile, Petrol

class BootstrapAuthenticationForm(AuthenticationForm):
    """Authentication form which uses boostrap CSS."""
    username = forms.CharField(max_length=254,
                               widget=forms.TextInput({
                                   'class': 'form-control',
                                   'placeholder': 'User name'}))
    password = forms.CharField(label=_("Password"),
                               widget=forms.PasswordInput({
                                   'class': 'form-control',
                                   'placeholder':'Password'}))

class RegisterForm(UserCreationForm):
    username = forms.CharField(
        max_length=150,
        widget=forms.TextInput({'class': 'form-control', 'placeholder': 'Username'})
    )
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput({'class': 'form-control', 'placeholder': 'Email'})
    )
    phone_number = forms.CharField(
        max_length=15,
        required=True,
        widget=forms.TextInput({'class': 'form-control', 'placeholder': 'Phone Number'})
    )
    password1 = forms.CharField(
        label="Password",
        widget=forms.PasswordInput({'class': 'form-control', 'placeholder': 'Password'})
    )
    password2 = forms.CharField(
        label="Confirm Password",
        widget=forms.PasswordInput({'class': 'form-control', 'placeholder': 'Confirm Password'})
    )

    class Meta:
        model = User  # Use CustomUser if you have one
        fields = ["username", "email", "phone_number", "password1", "password2"]

class ProfileForm(forms.ModelForm):
    email = forms.EmailField(required=True)  # Ensure email is a required field

    class Meta:
        model = Profile
        fields = ["name", "address", "phone_number", "email"]

    def __init__(self, *args, **kwargs):
        user = kwargs.pop("user", None)  # Extract user from kwargs
        super().__init__(*args, **kwargs)

        if user:
            # Load existing data
            profile = getattr(user, "profile", None)  # Use getattr to avoid AttributeError
            if profile:
                self.fields["name"].initial = profile.name
                self.fields["address"].initial = profile.address
                self.fields["phone_number"].initial = profile.phone_number
            
            self.fields["email"].initial = user.email  # Fetch email from User model

    def save(self, commit=True):
        profile = super().save(commit=False)
        user = profile.user  # Get associated user
        user.email = self.cleaned_data["email"]  # Save email to User model

        if commit:
            user.save()  # Save User model first
            profile.save()  # Save Profile model

        return profile

class SupplierProfileForm(forms.ModelForm):
    class Meta:
        model = SupplierProfile
        fields = ["company_name", "phone_number", "address"]

class PetrolForm(forms.ModelForm):
    class Meta:
        model = Petrol
        fields = ["price_per_liter", "available_amount"]  # Exclude 'petrol_type'